
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 

#Veri seti okunup veriler değişkenine atanır
veriler = pd.read_csv('FINENE_1.csv')

#Verilerin ilgili kısımları X ve Y değişkenlerine atanır
X = veriler.iloc[:,0:11].values
Y = veriler.iloc[:,11].values

#encoder:  Kategorik -> Numeric
from sklearn.preprocessing import LabelEncoder

#present ve absent kelimeleri 1 ve 0 olarak değiştirilir
for i in range(1, 11):
    le = LabelEncoder()
    X[:,i] = le.fit_transform(X[:,i])

#bening ve absent kelimeleri 1 ve 0 olarak değiştirilir    
le2 = LabelEncoder()
Y = le2.fit_transform(Y)

from sklearn.preprocessing import OneHotEncoder
ohe = OneHotEncoder(categorical_features=[1])
X=ohe.fit_transform(X).toarray()
X = X[:,1:]

#verilerin egitimi ve test icin bolunmesi %20si test için ayrılır
from sklearn.cross_validation import train_test_split
x_train, x_test,y_train,y_test = train_test_split(X,Y,test_size=0.2, random_state=0)

#veriler ölçeklenir
from sklearn.preprocessing import StandardScaler

sc = StandardScaler()
X_train = sc.fit_transform(x_train)
X_test = sc.fit_transform(x_test)

#3 Yapay Sinir ağı oluşturulur
import keras
from keras.models import Sequential
from keras.layers import Dense

classifier = Sequential()

classifier.add(Dense(128, init = 'uniform', activation = 'relu' , input_dim = 11))

classifier.add(Dense(128, init = 'uniform', activation = 'relu'))

classifier.add(Dense(1, init = 'uniform', activation = 'sigmoid'))

classifier.compile(optimizer = 'adam', loss =  'binary_crossentropy' , metrics = ['accuracy'] )

classifier.fit(X_train, y_train, epochs=100)

#Test ve train verilerinin doğruluk oranlarına bakılır
lossTest,accuracyTest = classifier.evaluate(X_test,y_test)
lossTrain,accuracyTrain = classifier.evaluate(X_train,y_train)

#elde edilen çıktılar y_pred degiskenine atanır ve yazdırılır
#sfıra yakın değerler iyi huylu  100e yakın değerler ise kötü huylu 
#y_pred = classifier.predict(X_test)
#print(y_pred)


